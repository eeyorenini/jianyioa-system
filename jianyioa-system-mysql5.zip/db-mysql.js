// MySQL 同步适配层
// 提供与 better-sqlite3 相似的 API (prepare/get/all/run/exec)
// 底层用 mysql2/promise + deasync 实现同步语义
// 这样 server.js 主体逻辑不用改，0 业务代码迁移

const mysql = require('mysql2/promise');
const deasync = require('deasync');
const dotenv = require('dotenv');

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'jianyioa',
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_POOL_LIMIT) || 10,
  queueLimit: 0,
  charset: 'utf8mb4',
  dateStrings: true,  // 返回字符串格式的日期（与 SQLite 行为一致）
  multipleStatements: false
});

// 同步执行任意 SQL，返回 rows
function syncQuery(sql, params) {
  let result, err, done = false;
  pool.query(sql, params || [])
    .then(([rows]) => { result = rows; done = true; })
    .catch(e => { err = e; done = true; });
  while (!done) deasync.runLoopOnce();
  if (err) throw err;
  return result;
}

// 兼容 better-sqlite3 的 prepare().get()
function get(sql, params) {
  const rows = syncQuery(sql, params);
  return rows[0] || undefined;
}

// 兼容 better-sqlite3 的 prepare().all()
function all(sql, params) {
  return syncQuery(sql, params);
}

// 兼容 better-sqlite3 的 prepare().run()
// 返回 { lastInsertRowid, changes }
function run(sql, params) {
  let result, err, done = false;
  pool.query(sql, params || [])
    .then(([res]) => {
      result = {
        lastInsertRowid: res.insertId,
        changes: res.affectedRows
      };
      done = true;
    })
    .catch(e => { err = e; done = true; });
  while (!done) deasync.runLoopOnce();
  if (err) throw err;
  return result;
}

// 兼容 better-sqlite3 的 exec() — 执行多语句
function exec(sql) {
  // 拆分多语句（按 ; 切分，但要忽略字符串里的 ;）
  const statements = sql
    .split(/;\s*(?=(?:[^'"]*['"][^'"]*['"])*[^'"]*$)/)
    .map(s => s.trim())
    .filter(s => s.length > 0);
  for (const stmt of statements) {
    try {
      syncQuery(stmt);
    } catch (e) {
      // ALTER TABLE 之类已存在的字段错误忽略
      if (!/Duplicate column name|already exists/i.test(e.message)) {
        throw e;
      }
    }
  }
  return undefined;
}

// pragma 是 SQLite 特有，MySQL 改为空操作
function pragma(_sql) {
  // 忽略，MySQL 不需要
}

// 占位转换: SQLite 的 ? 占位符与 mysql2 兼容，无需改动
// 唯一差异：SQLite 的 `datetime('now')` 等函数 → MySQL 的 NOW()
// 但 server.js 里大部分时间都靠 DEFAULT CURRENT_TIMESTAMP 走，少数函数调用需要在 SQL 里替换

// Statement 类（模拟 better-sqlite3 的 prepare 返回对象）
class Statement {
  constructor(sql) { this.sql = sql; }
  get(params) { return get(this.sql, params); }
  all(params) { return all(this.sql, params); }
  run(params) { return run(this.sql, params); }
}

// Database 类（模拟 better-sqlite3 的 Database 构造器）
class Database {
  constructor(config) {
    // config 兼容 SQLite 的 path 参数，但 MySQL 走环境变量
    // 这里不再需要路径
  }
  prepare(sql) { return new Statement(sql); }
  exec(sql) { return exec(sql); }
  pragma(sql) { return pragma(sql); }
  // 关闭连接池
  close() {
    let done = false;
    pool.end().then(() => { done = true; }).catch(() => { done = true; });
    while (!done) deasync.runLoopOnce();
  }
}

module.exports = Database;
module.exports.pool = pool;
